<?php

use yii\helpers\Html;

$this->title = 'Pesquisa';
?>

<div class="site-pesquisa">
    <h1><?= Html::encode($this->title) ?></h1>

    <p>Incentivamos a pesquisa científica e projetos inovadores dentro e fora da sala de aula.</p>
</div>
