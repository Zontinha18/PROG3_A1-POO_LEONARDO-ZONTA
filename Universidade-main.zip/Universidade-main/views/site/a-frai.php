<?php

use yii\helpers\Html;

$this->title = 'A Frai do Vale';
?>

<div class="site-a-frai">
    <h1><?= Html::encode($this->title) ?></h1>

    <p>A <strong>Frai do Vale</strong> é uma instituição de ensino superior localizada em Fraiburgo-SC, comprometida com a excelência acadêmica e formação profissional.</p>
</div>
