<?php

use yii\helpers\Html;

$this->title = 'Estude na Frai';
?>

<div class="site-estude">
    <h1><?= Html::encode($this->title) ?></h1>

    <p>Estude na Frai do Vale e tenha acesso à qualidade de ensino, laboratórios modernos e professores altamente qualificados.</p>
</div>
