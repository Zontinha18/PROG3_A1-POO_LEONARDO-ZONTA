<?php

use yii\helpers\Html;

$this->title = 'Central de Apoio';
?>

<div class="site-central">
    <h1><?= Html::encode($this->title) ?></h1>

    <p>A Central de Apoio oferece suporte acadêmico, financeiro e psicológico aos alunos.</p>
</div>
