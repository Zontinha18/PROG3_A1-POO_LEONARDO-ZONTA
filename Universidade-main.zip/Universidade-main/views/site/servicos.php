<?php

use yii\helpers\Html;

$this->title = 'Serviços';
?>

<div class="site-servicos">
    <h1><?= Html::encode($this->title) ?></h1>

    <p>Serviços oferecidos pela Frai do Vale aos alunos e à comunidade.</p>
</div>
