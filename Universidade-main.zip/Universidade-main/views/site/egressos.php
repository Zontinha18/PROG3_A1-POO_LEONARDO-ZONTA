<?php

use yii\helpers\Html;

$this->title = 'Egressos';
?>

<div class="site-egressos">
    <h1><?= Html::encode($this->title) ?></h1>

    <p>Conecte-se com a rede de ex-alunos da Frai do Vale e fortaleça sua carreira.</p>
</div>
